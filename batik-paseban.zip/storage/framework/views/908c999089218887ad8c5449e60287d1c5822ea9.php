<?php $__env->startSection('content'); ?>
<div class="content-heading">
	<div>
		Sentra Batik
	</div>
</div>
<div class="container-fluid">
	<div class="col-md-6 offset-md-3">
		<div class="card">
			<div class="card-header">
				<div class="card-title">
					Edit Sentra Batik
					<div class="float-right">

					</div>
				</div>
			</div>
			<div class="card-body">
				<form action="<?php echo e(route('sentra-batik.update', $sentra->hashid)); ?>" method="POST">
					<?php echo method_field('PUT'); ?>
					<?php echo csrf_field(); ?>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label text-right">Nama Sentra</label>
						<div class="col-sm-7">
							<input autofocus class="form-control" required type="text" name="nama" value="<?php echo e(old('nama') ? old('nama'):$sentra->nama); ?>" placeholder="" />
							<?php if($errors->has('nama')): ?>
							<span class="invalid-feedback">
								<strong><?php echo e($errors->first('nama')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label text-right">Lokasi</label>
						<div class="col-sm-7">
							<textarea autofocus class="form-control" required type="text" name="lokasi" value="<?php echo e(old('lokasi') ? old('nama'):$sentra->lokasi); ?>" placeholder="" ><?php echo e(old('lokasi') ? old('nama'):$sentra->lokasi); ?></textarea>
							<?php if($errors->has('lokasi')): ?>
							<span class="invalid-feedback">
								<strong><?php echo e($errors->first('lokasi')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-xl-3 col-form-label text-right">Tahun Berdiri</label>
						<div class="col-xl-7">
							<select required name="tahun" class="custom-select custom-select-sm <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('tahun')); ?>>
								<option value="">Pilih Tahun</option>
								<?php
								$thn_skr = date('Y');
								for ($x = $thn_skr; $x >= 1998; $x--) {
									?>
									<option value="<?php echo e($x); ?>" <?php if(old('tahun', $sentra->tahun) == $x): ?> selected <?php endif; ?>><?php echo e($x); ?></option>
									<?php
								}
								?>
							</select>
							<?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback"><?php echo e($message); ?></div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-xl-3 col-form-label text-right">Negara</label>
						<div class="col-xl-7">
							<select required name="negara" class="custom-select custom-select-sm <?php $__errorArgs = ['negara'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('negara')); ?>>
								<option value="Indonesia" <?php if(old('Indonesia', $sentra->negara) == "Indonesia"): ?> selected <?php endif; ?>>Indonesia</option>
								<option value="Malaysia" <?php if(old('Malaysia', $sentra->negara) == "Malaysia"): ?> selected <?php endif; ?>>Malaysia</option>
							</select>
							<?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback"><?php echo e($message); ?></div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label text-right">Pemilik</label>
						<div class="col-sm-7">
							<input autofocus class="form-control" required type="text" name="pemilik" value="<?php echo e(old('pemilik') ? old('nama'):$sentra->pemilik); ?>" placeholder="" />
							<?php if($errors->has('pemilik')): ?>
							<span class="invalid-feedback">
								<strong><?php echo e($errors->first('pemilik')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-sm-12">
						<div class="form-group row">
							<div class="col-xl-12 text-center">
								<a href="<?php echo e(route('sentra-batik.index')); ?>" class="btn btn-secondary">Kembali</a>
								<button class="btn btn-primary mb-2 mt-2" type="submit">Simpan</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAM_JANGAN_DIHAPUS\xampp73\htdocs\idam_tech\Laravel6\batik\resources\views/pages/sentra/edit.blade.php ENDPATH**/ ?>