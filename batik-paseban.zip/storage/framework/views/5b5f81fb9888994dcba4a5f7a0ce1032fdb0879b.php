<div class="p-3 text-center">
    <span class="mr-2">&copy; 2020</span>
    <span class="mr-2">-</span>
    <span>Batik Paseban</span>
</div>
<?php /**PATH E:\PROGRAM_JANGAN_DIHAPUS\xampp73\htdocs\idam_tech\Laravel6\batik-paseban\resources\views/layouts/includes/footer-page.blade.php ENDPATH**/ ?>