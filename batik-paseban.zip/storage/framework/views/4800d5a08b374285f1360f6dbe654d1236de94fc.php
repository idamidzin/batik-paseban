<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="Bootstrap Admin App" />
    <meta name="keywords" content="app, responsive, jquery, bootstrap, dashboard, admin" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="icon" type="image/x-icon" href="/favicon.ico" />

    <title>Authentic Batik</title>

    <!-- =============== VENDOR STYLES ===============-->
    <link rel="stylesheet" href="<?php echo e(mix('/css/vendor.css')); ?>" />
    <!-- =============== BOOTSTRAP STYLES ===============-->
    <link rel="stylesheet" href="<?php echo e(mix('/css/bootstrap.css')); ?>" data-rtl="<?php echo e(mix('/css/bootstrap-rtl.css')); ?>" id="bscss" />
    <!-- =============== APP STYLES ===============-->
    <link rel="stylesheet" href="<?php echo e(mix('/css/app.css')); ?>" data-rtl="<?php echo e(mix('/css/app-rtl.css')); ?>" id="maincss" /> 
    <?php echo $__env->yieldContent('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(mix('/css/theme-e.css')); ?>">
    <style type="text/css">
      #list-tahun-pelajaran .list-group-item {
        cursor: pointer;
        -webkit-touch-callout: none;
        -webkit-user-select: none;
         -khtml-user-select: none;
           -moz-user-select: none;
            -ms-user-select: none;
                user-select: none;
      }
      #dropdown-user .dropdown-item .list-group a{text-decoration: none;}
      @media (max-width: 576px) {
        .topnavbar .navbar-header .brand-logo {font-size: 0.8rem;}
      }
      .bg-blue-grey {
          background-color: #607D8B !important;
          color: #fff;
      }
      .btn.bg-blue-grey:hover,
      .btn.bg-blue-grey:active,
      .btn.bg-blue-grey:focus{
        color: #fff;
        background-color: #4D646F !important;
      }
      ul.sidebar-nav span {white-space: normal;}
    </style>
  </head>

  <body>
    <div class="wrapper">
      <!-- top navbar-->
      <?php echo $__env->make('layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- sidebar-->
      <?php echo $__env->make('layouts.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- offsidebar-->
      <?php echo $__env->make('layouts.includes.offsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Main section-->
      <section class="section-container">
        <!-- Page content-->
        <div class="content-wrapper">
          <?php echo $__env->yieldContent('content'); ?>
        </div>
      </section>
      <!-- Page footer-->
      <?php echo $__env->make('layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->yieldContent('body-area'); ?>
    <!-- =============== VENDOR SCRIPTS ===============-->
    <script src="<?php echo e(mix('/js/manifest.js')); ?>"></script>
    <script src="<?php echo e(mix('/js/vendor.js')); ?>"></script>
    <!-- =============== APP SCRIPTS ===============-->
    <script src="<?php echo e(mix('/js/app.js')); ?>"></script>
    <!-- =============== CUSTOM PAGE SCRIPTS ===============-->
    <?php echo $__env->yieldContent('scripts'); ?>
    <script type="text/javascript">
      $(document).ready(function(){
        if ($(".alert-remove").length > 0) {
          let delay = $(".alert-remove").data('delay',false);
          $(".alert-remove").delay(delay !== false ? delay : 2000).slideUp(500);
        }

      })
    </script>
  </body>

</html><?php /**PATH E:\PROGRAM_JANGAN_DIHAPUS\xampp73\htdocs\idam_tech\Laravel6\batik\resources\views/layouts/app.blade.php ENDPATH**/ ?>