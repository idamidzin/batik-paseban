<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <meta name="description" content="Bootstrap Admin App" />
        <meta name="keywords" content="app, responsive, jquery, bootstrap, dashboard, admin" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <link rel="icon" type="image/x-icon" href="favicon.ico" />

        <title>Galoon</title>

        <!-- =============== VENDOR STYLES ===============-->
        <link rel="stylesheet" href="<?php echo e(mix('/css/vendor.css')); ?>" />
        <!-- =============== BOOTSTRAP STYLES ===============-->
        <link rel="stylesheet" href="<?php echo e(mix('/css/bootstrap.css')); ?>" data-rtl="<?php echo e(mix('/css/bootstrap-rtl.css')); ?>" id="bscss" />
        <!-- =============== APP STYLES ===============-->
        <link rel="stylesheet" href="<?php echo e(mix('/css/app.css')); ?>" data-rtl="<?php echo e(mix('/css/app-rtl.css')); ?>" id="maincss" />

        <?php echo $__env->yieldContent('styles'); ?>
    </head>

    <body>
        <div class="wrapper">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->yieldContent('body-area'); ?>
        <!-- =============== VENDOR SCRIPTS ===============-->
        <script src="<?php echo e(mix('/js/manifest.js')); ?>"></script>
        <script src="<?php echo e(mix('/js/vendor.js')); ?>"></script>
        <!-- =============== APP SCRIPTS ===============-->
        <script src="<?php echo e(mix('/js/app.js')); ?>"></script>
        <!-- =============== CUSTOM PAGE SCRIPTS ===============-->
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH E:\PROGRAM_JANGAN_DIHAPUS\xampp73\htdocs\idam_tech\Laravel6\galoon\resources\views/layouts/user.blade.php ENDPATH**/ ?>