<div class="p-3 text-center">
    <span class="mr-2">&copy; 2020</span>
    <span class="mr-2">-</span>
    <span>PT. Galoon</span>
</div>
<?php /**PATH E:\PROGRAM_JANGAN_DIHAPUS\xampp73\htdocs\idam_tech\Laravel6\batik\resources\views/layouts/includes/footer-page.blade.php ENDPATH**/ ?>