<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="Bootstrap Admin App" />
    <meta name="keywords" content="app, responsive, jquery, bootstrap, dashboard, admin" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="icon" type="image/x-icon" href="/favicon.ico" />

    <title>Angle - Bootstrap Admin Template</title>

    <!-- =============== VENDOR STYLES ===============-->
    <link rel="stylesheet" href="<?php echo e(mix('/css/vendor.css')); ?>" />
    <!-- =============== BOOTSTRAP STYLES ===============-->
    <link rel="stylesheet" href="<?php echo e(mix('/css/bootstrap.css')); ?>" data-rtl="<?php echo e(mix('/css/bootstrap-rtl.css')); ?>" id="bscss" />
    <!-- =============== APP STYLES ===============-->
    <link rel="stylesheet" href="<?php echo e(mix('/css/app.css')); ?>" data-rtl="<?php echo e(mix('/css/app-rtl.css')); ?>" id="maincss" /> <?php echo $__env->yieldContent('styles'); ?>
  </head>

  <body>
    <div class="wrapper">
      <!-- top navbar-->
      <?php echo $__env->make('layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- sidebar-->
      <?php echo $__env->make('layouts.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- offsidebar-->
      <?php echo $__env->make('layouts.includes.offsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Main section-->
      <section class="section-container">
        <!-- Page content-->
        <div class="content-wrapper">
          <?php echo $__env->yieldContent('content'); ?>
        </div>
      </section>
      <!-- Page footer-->
      <?php echo $__env->make('layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->yieldContent('body-area'); ?>
    <!-- =============== VENDOR SCRIPTS ===============-->
    <script src="<?php echo e(mix('/js/manifest.js')); ?>"></script>
    <script src="<?php echo e(mix('/js/vendor.js')); ?>"></script>
    <!-- =============== APP SCRIPTS ===============-->
    <script src="<?php echo e(mix('/js/app.js')); ?>"></script>
    <!-- =============== CUSTOM PAGE SCRIPTS ===============-->
    <?php echo $__env->yieldContent('scripts'); ?>
  </body>

</html><?php /**PATH E:\webfiles\SIMBU\laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>