<?php $__env->startSection('content'); ?>
<div class="content-heading">
	<div>
		Motif
	</div>
</div>
<div class="container-fluid">
	<div class="col-md-6 offset-md-3">
		<div class="card">
			<div class="card-header">
				<div class="card-title">
					Edit Motif
					<div class="float-right">

					</div>
				</div>
			</div>
			<div class="card-body">
				<form action="<?php echo e(route('motif.update', $motif->hashid)); ?>" method="POST" enctype="multipart/form-data">
					<?php echo method_field('PUT'); ?>
					<?php echo csrf_field(); ?>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label text-right">Nama</label>
						<div class="col-sm-7">
							<input autofocus class="form-control" required type="text" name="nama" value="<?php echo e(old('nama') ? old('nama'):$motif->nama); ?>" placeholder="" />
							<?php if($errors->has('nama')): ?>
							<span class="invalid-feedback">
								<strong><?php echo e($errors->first('nama')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label text-right">Asal Daerah</label>
						<div class="col-sm-7">
							<input autofocus class="form-control" required type="text" name="asal_daerah" value="<?php echo e(old('asal_daerah') ? old('nama'):$motif->asal_daerah); ?>" placeholder="" />
							<?php if($errors->has('asal_daerah')): ?>
							<span class="invalid-feedback">
								<strong><?php echo e($errors->first('asal_daerah')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label text-right">Cara Pembuatan</label>
						<div class="col-sm-7">
							<textarea autofocus class="form-control" required type="text" name="cara_pembuatan" placeholder=""><?php echo e(old('cara_pembuatan') ? old('nama'):$motif->cara_pembuatan); ?></textarea>
							<?php if($errors->has('cara_pembuatan')): ?>
							<span class="invalid-feedback">
								<strong><?php echo e($errors->first('cara_pembuatan')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label text-right">Warna</label>
						<div class="col-sm-7">
							<input autofocus class="form-control" required type="text" name="warna" value="<?php echo e(old('warna') ? old('nama'):$motif->warna); ?>" placeholder="" />
							<?php if($errors->has('warna')): ?>
							<span class="invalid-feedback">
								<strong><?php echo e($errors->first('warna')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label text-right">Nama Pembuat</label>
						<div class="col-sm-7">
							<input autofocus class="form-control" required type="text" name="nama_pembuat" value="<?php echo e(old('nama_pembuat') ? old('nama'):$motif->nama_pembuat); ?>" placeholder="" />
							<?php if($errors->has('nama_pembuat')): ?>
							<span class="invalid-feedback">
								<strong><?php echo e($errors->first('nama_pembuat')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label text-right">Foto</label>
						<div class="col-sm-7">
							<?php if(!is_null($motif->foto)): ?>
								<img src="<?php echo e(asset('storage/batik/'.$motif->foto)); ?>" width="80"> 
							<?php else: ?>
								<img src="<?php echo e(asset('img/dummy.png')); ?>" width="80"> 
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-3 col-form-label text-right">Citra</label>
						<div class="col-sm-7">
							<input autofocus class="form-control" required readonly type="text" name="nilai_citra" value="<?php echo e(old('nilai_citra') ? old('nama'):$motif->nilai_citra); ?>" placeholder="" />
							<?php if($errors->has('nilai_citra')): ?>
							<span class="invalid-feedback">
								<strong><?php echo e($errors->first('nilai_citra')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-sm-12">
						<div class="form-group row">
							<div class="col-xl-12 text-center">
								<a href="<?php echo e(route('motif.index')); ?>" class="btn btn-secondary">Kembali</a>
								<button class="btn btn-primary mb-2 mt-2" type="submit">Simpan</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAM_JANGAN_DIHAPUS\xampp73\htdocs\idam_tech\Laravel6\batik\resources\views/pages/motif/edit.blade.php ENDPATH**/ ?>