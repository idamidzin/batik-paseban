<footer class="footer-container">
    <span>&copy; 2020 - Angle</span>
</footer>
<?php /**PATH E:\webfiles\SIMBU\laravel\resources\views/layouts/includes/footer.blade.php ENDPATH**/ ?>