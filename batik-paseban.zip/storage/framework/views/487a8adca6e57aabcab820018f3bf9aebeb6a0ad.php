<div class="p-3 text-center">
    <span class="mr-2">&copy; 2020</span>
    <span class="mr-2">-</span>
    <span>Angle</span>
    <br />
    <span>Bootstrap Admin Template</span>
</div>
<?php /**PATH E:\webfiles\SIMBU\laravel\resources\views/layouts/includes/footer-page.blade.php ENDPATH**/ ?>