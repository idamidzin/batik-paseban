<footer class="footer-container">
    <span>&copy; 2020 - Go.Galoon</span>
</footer>
<?php /**PATH E:\PROGRAM_JANGAN_DIHAPUS\xampp73\htdocs\idam_tech\Laravel6\galoon\resources\views/layouts/includes/footer.blade.php ENDPATH**/ ?>