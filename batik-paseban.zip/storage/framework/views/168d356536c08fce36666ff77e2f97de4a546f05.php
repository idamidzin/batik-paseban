<?php $__env->startSection('content'); ?>
    <div class="block-center mt-4 wd-xl">
        <!-- START card-->
        <div class="card card-flat">
            <div class="card-header text-center bg-dark">
                <a href="#"><img class="block-center rounded" style="max-width: 128px;" src="img/logo512.png" alt="Image" /></a>
            </div>
            <div class="card-body">
                <?php if( session('msg') ): ?>
                <?php 
                    $msg = session('msg');
                 ?>
                    <div class="alert alert-<?php echo e($msg['type']); ?>">
                        <p><?php echo $msg['text']; ?></p>
                    </div>
                <?php endif; ?>
                <p class="text-center py-2">Login untuk melanjutkan.</p>
                <form method="POST" class="mb-3" id="loginForm" novalidate="novalidate" action="<?php echo e(route('login.proses')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="input-group with-focus">
                            <input minlength="4" maxlength="30" class="form-control border-right-0" type="text" placeholder="Masukan username" autocomplete="off" required="required" name="username" value="<?php echo e(old('email')); ?>" />
                            <div class="input-group-append">
                                <span class="input-group-text text-muted bg-transparent border-left-0"><em class="fa fa-envelope"></em></span>
                            </div>
                        </div>
                        <?php if($errors->has('username')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('username')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <div class="input-group with-focus">
                            <input  minlength="4" maxlength="30" class="form-control border-right-0" type="password" name="password" placeholder="Masukan Password" required="required" />
                            <div class="input-group-append">
                                <span class="input-group-text text-muted bg-transparent border-left-0"><em class="fa fa-lock"></em></span>
                            </div>
                        </div>
                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="clearfix">
                        <div class="checkbox c-checkbox float-left mt-0">
                            <label>
                                <input type="checkbox" value="" name="remember" />
                                <span class="fa fa-check"></span>
                                Remember Me
                            </label>
                        </div>
                    </div>
                    <button class="btn btn-block btn-dark mt-3" type="submit">Login</button>
                </form>
            </div>
        </div>
        <?php echo $__env->make("layouts.includes.footer-page", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(mix('/js/pages.js')); ?>"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        if ($(".alert-remove").length > 0) {
          let delay = $(".alert-remove").data('delay',false);
          $(".alert-remove").delay(delay !== false ? delay : 2000).slideUp(500);
        }
      })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAM_JANGAN_DIHAPUS\xampp73\htdocs\idam_tech\Laravel6\galoon\resources\views/auth/login.blade.php ENDPATH**/ ?>