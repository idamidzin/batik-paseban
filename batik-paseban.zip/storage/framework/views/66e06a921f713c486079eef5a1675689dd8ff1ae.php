<footer class="footer-container">
    <span>&copy; 2020 - Authentic Batik</span>
</footer>
<?php /**PATH E:\PROGRAM_JANGAN_DIHAPUS\xampp73\htdocs\idam_tech\Laravel6\batik\resources\views/layouts/includes/footer.blade.php ENDPATH**/ ?>