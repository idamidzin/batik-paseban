<aside class="aside-container">
    <!-- START Sidebar (left)-->
    <div class="aside-inner">
        <nav class="sidebar" data-sidebar-anyclick-close="<?php echo e(sizeof($sidebarMenu)); ?>">
            <!-- START sidebar nav-->
            <ul class="sidebar-nav">
                <!-- START user info-->
                <li class="has-user-block">
                    <div class="collapse" id="user-block">
                        <div class="item user-block">
                            <!-- User picture-->
                            <div class="user-block-picture">
                                <div class="user-block-status">
                                    <img class="img-thumbnail rounded-circle" src="/img/user/02.jpg" alt="Avatar" width="60" height="60" />
                                    <div class="circle bg-success circle-lg"></div>
                                </div>
                            </div>
                            <!-- Name and Job-->
                            <div class="user-block-info">
                                <span class="user-block-name">Hello, Mike</span>
                                <span class="user-block-role">Designer</span>
                            </div>
                        </div>
                    </div>
                </li>
                <!-- END user info-->

                <?php $__currentLoopData = $sidebarMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if(isset($item['heading'])): ?>
                        <li class="nav-heading ">
                            <span data-localize="<?php echo e($item['translate'] ?? ''); ?>"><?php echo e($item['text']); ?></span>
                        </li>

                    
                    <?php elseif(isset($item['submenu'])): ?>
                        <?php $collapseId = 'menu-'.Str::slug($item['text']); ?>
                        <li class="<?php echo e(\Request::is($item['route'].'*') ? ' active' : ''); ?>">
                            <a href="<?php echo e('#'.$collapseId); ?>" title="<?php echo e($item['text']); ?>" data-toggle="collapse">
                                <em class="<?php echo e($item['icon']); ?>"></em>
                                <span data-localize="<?php echo e($item['translate'] ?? ''); ?>"><?php echo e($item['text']); ?></span>
                            </a>
                            <ul class="sidebar-nav sidebar-subnav collapse <?php echo e(\Request::is($item['route'].'/*') ? 'show' : ''); ?>" id="<?php echo e($collapseId); ?>">
                                <li class="sidebar-subnav-header"><?php echo e($item['text']); ?></li>

                                <?php $__currentLoopData = $item['submenu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    
                                    <?php if(isset($subitem['submenu'])): ?>

                                        <?php $collapseId = 'submenu-'.Str::slug($subitem['text']); ?>
                                        <li class="<?php echo e(\Request::is($subitem['route'].'*') ? ' active' : ''); ?>">
                                            <a href="<?php echo e('#'.$collapseId); ?>" title="<?php echo e($subitem['text']); ?>" data-toggle="collapse">
                                                <em class="<?php echo e($subitem['icon']); ?>"></em>
                                                <span data-localize="<?php echo e($subitem['translate'] ?? ''); ?>"><?php echo e($subitem['text']); ?></span>
                                            </a>
                                            <ul class="sidebar-nav sidebar-subnav collapse <?php echo e(\Request::is($subitem['route'].'/*') ? 'show' : ''); ?>" id="<?php echo e($collapseId); ?>">
                                                <li class="sidebar-subnav-header"><?php echo e($subitem['text']); ?></li>

                                                <?php $__currentLoopData = $subitem['submenu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsubitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="<?php echo e(\Request::is($subsubitem['route']) ? ' active' : ''); ?>">
                                                        <a href="<?php echo e(url($subsubitem['route'])); ?>" title="<?php echo e($subsubitem['text']); ?>">
                                                            <span data-localize="<?php echo e($subsubitem['translate'] ?? ''); ?>"><?php echo e($subsubitem['text']); ?></span>
                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </ul>
                                        </li>

                                    
                                    <?php else: ?>
                                        <li class="<?php echo e(\Request::is($subitem['route']) ? ' active' : ''); ?>">
                                            <a href="<?php echo e(url($subitem['route'])); ?>" title="<?php echo e($subitem['text']); ?>">
                                                <span data-localize="<?php echo e($subitem['translate'] ?? ''); ?>"><?php echo e($subitem['text']); ?></span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </li>

                    
                    <?php else: ?>
                        <li class="<?php echo e(\Request::is($item['route']) ? ' active' : ''); ?>">
                            <a href="<?php echo e(url($item['route'])); ?>" title="<?php echo e($item['text']); ?>">
                                <em class="<?php echo e($item['icon']); ?>"></em>
                                <span data-localize="<?php echo e($item['translate'] ?? ''); ?>"><?php echo e($item['text']); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <!-- END sidebar nav-->
        </nav>
    </div>
    <!-- END Sidebar (left)-->
</aside>
<?php /**PATH E:\webfiles\SIMBU\laravel\resources\views/layouts/includes/sidebar.blade.php ENDPATH**/ ?>