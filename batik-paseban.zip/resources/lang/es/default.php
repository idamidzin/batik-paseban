<?php

return [

	'dashboard' => array(
		'WELCOME' => 'Bienvenido a Angle',
	),
	'topbar' => array(
		'search' => array(
			'PLACEHOLDER' => 'Tipea y pulsa enter..',
		),
	),
	'sidebar' => array(
		'WELCOME' => 'Bienvenido',
		'heading' => array(
			'HEADER' => 'Navegacion principal',
		),
		'nav' => array(
			'SINGLEVIEW' => 'Vista simple',
			'menu' => array(
				'MENU' => 'Menu',
				'SUBMENU' => 'Sub Menu',
			),
		),
	),

];
