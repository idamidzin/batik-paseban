<footer class="footer-container">
    <span>&copy; 2020 - Go.Galoon</span>
</footer>
