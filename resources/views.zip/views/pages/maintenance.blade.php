@extends('layouts.user')
@section('content')
    <div class="abs-center">
        <div class="text-center my-3">
            <div class="h1 mb-3">
                <sup><em class="fa fa-cog fa-2x text-muted fa-spin text-info"></em></sup>
                <em class="fa fa-cog fa-5x text-muted fa-spin text-purple"></em>
                <em class="fa fa-cog fa-lg text-muted fa-spin text-success"></em>
            </div>
            <div class="text-bold text-lg mb-3">SITE IS UNDER MAINTENANCE</div>
            <p class="lead m-0">We'll back online shortly!</p>
        </div>
    </div>
@endsection
